***

title: Theme store requirements
description: >-
Follow these requirements to make sure your theme provides a high-quality
experience to merchants.
source\_url:
html: '<https://shopify.dev/docs/storefronts/themes/store/requirements>'
md: '<https://shopify.dev/docs/storefronts/themes/store/requirements.md>'
api\_name: liquid
-----------------

# Theme store requirements

Our Theme Store is a canvas for creativity, innovation, and merchant expression. We’re looking for unique, original submissions that push design boundaries, offer standout visual quality, and deliver delightful, engaging user experiences. Themes should be visually distinctive, professionally crafted, and empower merchants to tell their brand's story clearly and expressively. We value themes that not only meet merchants' functional business needs, but also actively inspire merchants and their customers, elevating online shopping experiences through thoughtful layouts, bold visuals, purposeful creativity, and intuitive, high-quality usability.

[Themes and presets](https://shopify.dev/docs/storefronts/themes/architecture/config/settings-data-json) published on the Shopify Theme Store must meet all requirements. If your submission misses any requirement, then it will be rejected and you'll need to make corrections before resubmitting.

Test your theme thoroughly before submitting to ensure it meets functionality and quality standards. Poorly tested themes will be rejected without further review, and repeated issues may lead to suspension or permanent rejection.

Learn about the theme review process and how to [submit your theme to the Shopify Theme Store](https://shopify.dev/docs/storefronts/themes/store/review-process/submit-theme).

***

## 1.​Theme Store exclusivity

Themes on the Theme Store must be exclusive to the Theme Store and can't contain external marketing material, so merchants can continue to benefit from the highest quality themes and the newest features.

All themes must meet the following exclusivity requirements:

Themes listed on the Shopify Theme Store can only be distributed through the Shopify Theme Store. Themes on the Theme Store must not be distributed on other marketplaces.Themes on the Shopify Theme Store can't contain designer credits, such as a link to a theme developer's website, or any affiliate links in the theme files.

***

## 2.​Uniqueness from other themes

Your theme must be fundamentally different from other themes on the [Shopify Theme Store](https://themes.shopify.com) (including your own). You must make meaningful design and functional innovations beyond minor cosmetic changes. Clear differentiation builds merchant trust by keeping theme quality high, and helps merchants find the right fit faster.

We use these standards to evaluate uniqueness:

* Uniqueness is measured by the overall experience across core templates and elements. You may reuse components and libraries, but how you assemble them must be substantially different.

* Your theme’s identity and capabilities must not be easily reproducible. They should not be achievable by adjusting settings, superficial styling, or adding a few sections or options to another theme. Reproducing your overall experience should require substantial structural changes to the theme.

* Use an inventive art direction that distinguishes the theme, with clear systems for header and navigation, product cards, media treatments, and page structure.

* Cosmetic or additive alterations are insufficient. For example: spacing tweaks, color or typography swaps, gradients, shape dividers, background effects or blurs, animation or transition tweaks, or adding a few settings or sections to an existing codebase.

* Embed uniqueness at the architectural level so the theme remains unmistakably its own as new settings, sections, and features are added.

* A merchant shouldn't be able to buy your theme then customize it to appear almost identical to a different theme on the Shopify Theme Store.

**Note:**

[Shopify's Skeleton Theme](https://github.com/shopify/skeleton-theme) is the only approved codebase for Theme Store development. Otherwise, themes must be built with fully original code. New theme submissions built on or derived from Dawn or Horizon are not eligible for the Shopify Theme Store.

***

## 3.​Theme design and UX

The UX & Design criteria below set clear, objective expectations for the exceptional quality required on the Shopify Theme Store. Themes must meet **every** checkpoint listed below to be accepted. If your theme fails any of these requirements, you must address the issue before acceptance.

### Visual design and art direction

Unique and intentional design: Your theme clearly stands apart, does not closely resemble existing themes on the Theme Store, and clearly targets a specific merchant type or industry with a thoughtful, deliberate visual style.Professional-quality visuals: All images, graphics, and icons across your theme are high-quality, clear, appropriately sized, and consistent. No blurry, stretched, pixelated, or clipart-level imagery is present.Simple, complementary color palette: You include cohesive colors throughout the theme. Colors work well together without clashing or reducing readability.

### Layout

Clear, organized page structure: Your design clearly follows a logical grid structure. Spacing and alignment between sections and blocks feel deliberate and consistent, making the page easy to scan and visually balanced.Clear content hierarchy: Your design intentionally guides user attention toward important elements first by clearly using size, color, contrast, and position to emphasize key details. Secondary information clearly appears smaller, lighter, or appropriately lower-priority, creating a clear design hierarchy that's easy to follow and visually appealing.Flexible layouts that look intentional: Layouts are designed deliberately to remain visually appealing, organized, and balanced, even when content length, number of images, or text quantity changes. Page structures remain attractive and professional, avoiding awkward gaps, large blank areas, or broken layouts when content varies.

### Consistency

Consistent typography: Avoid using an over abundance of fonts throughout the theme, choosing fonts that clearly complement each other visually. All text uses consistent font pairing everywhere, resulting in a clean, balanced look that's attractive and easy to read.Consistent visual and interaction design: Interactive elements such as buttons, links, and forms use consistent styles, size, colors, and behaviors everywhere in the theme.Settings clearly organized: Theme customization in the theme editor must be easy for merchants to understand and use. Settings must use simple, merchant-friendly language and be grouped logically so that common tasks are discoverable without extensive searching.Merchant-first theme editor experience: Themes in the Shopify Theme Store are evaluated using a merchant-first approach. Customization in the theme editor must be intuitive and consistent. Settings must prioritize merchant clarity and discoverability. There must be a balance between flexibility and opinionated settings.

### Customer shopping experience

**Clear & effortless navigation:** Customers can easily navigate from homepage to product discovery, product pages, cart, and checkout without confusion or friction.\*\*Thoughtful product discovery:\*\*Theme design thoughtfully guides customers toward relevant products or collections—clearly helping them discover items they might want, through intuitive menus, featured collections, or clearly presented recommendations.**Frictionless shopping interactions:** The shopping experience is smooth, easy, and completely frustration-free. All key customer actions—such as choosing product options, adding to cart, editing cart items, and moving to checkout—are clear, intuitive, and immediately responsive.

### Demo store experience

**Complete, realistic demo store:** Your demo store showcases a fully realistic example of a merchant’s business, using thoughtfully selected products, professional images, real-life scenarios, and clearly written, original text—no "Lorem Ipsum" or placeholder content.\*\*Relevant, intentional sections:\*\*All sections and features shown in your demo store explicitly fit the type of business being portrayed. Sections clearly make sense and realistically help merchants showcase their products—avoid using sections or interactions that do not logically support the store's products or message.\*\*Inspiring merchant experience:\*\*Your demo inspires merchants with engaging content, attractive layouts, and realistic, intentional product displays.

Learn more about [design best practices](https://shopify.dev/docs/storefronts/themes/best-practices/design).

***

## 4.​Features

Feature-rich themes support the varied needs of merchants, and enable each merchant to use a theme in a way that fits their business.

All themes must support the following features:

**Sections Everywhere** - Refer to **[Templates, sections, and blocks](https://shopify.dev/themes/store/requirements#templates)** to ensure compatibility with Online Store 2.0.

Learn more about [migrating a theme to OS 2.0](https://shopify.dev/docs/storefronts/themes/best-practices/version-control).

**Discounts** - [Display discount amounts](https://shopify.dev/docs/storefronts/themes/pricing-payments/discounts) for individual items and for entire orders in the cart, checkout, and order templates. Discounts must be supported on the Cart page.

Learn more about [discounts](https://help.shopify.com/manual/discounts).

**Accelerated checkout buttons** - Include [accelerated checkout buttons on product pages](https://shopify.dev/docs/storefronts/themes/architecture/templates/product#accelerated-checkout-buttons) and [cart pages](https://shopify.dev/docs/storefronts/themes/pricing-payments/accelerated-checkout#implementing-accelerated-checkout-buttons-in-your-theme) so that customers can checkout quickly.

Accelerated checkout buttons must be supported on the following pages:

* Product page

* Cart page

The branded dynamic and accelerator checkout button colors must not be modified.

Learn more about [accelerated checkout](https://help.shopify.com/manual/payments/accelerated-checkouts).

**Faceted search filtering** - Use [search filtering](https://shopify.dev/docs/storefronts/themes/navigation-search/filtering) so that customers can filter on collection and search pages based on product availability, price, type, vendor, and variant options. You need to support faceted search filtering on collection pages and search pages.**Gift cards** - Include a [gift card template](https://shopify.dev/docs/storefronts/themes/architecture/templates/gift-card-liquid) that renders the gift card page, which displays the gift card that's issued to a customer upon purchase.

Learn more about [gift cards](https://help.shopify.com/manual/products/gift-card-products).

**Image focal points** - Make sure that your theme supports the [focal point](https://shopify.dev/docs/storefronts/themes/architecture/settings/input-settings#image-focal-points) of an image. Focal points can be set in the theme editor `image_picker` setting, or from the **Files** page in the Shopify admin.**Images for social sharing** - Add a [`page_image`](https://shopify.dev/docs/api/liquid/objects/page#page-image) [object](https://shopify.dev/docs/api/liquid/objects/page#page-image) for social sharing so that merchants can display a thumbnail image in their post when they share a link to their online store on social media, such as on Facebook or Pinterest.

Learn more about [social media images](https://help.shopify.com/manual/online-store/images/showing-social-media-thumbnail-images).

**Country selection** - When merchants sell to other countries and regions [in their local currency](https://shopify.dev/docs/storefronts/themes/markets/multiple-currencies-languages#the-country-selector) customers must be able to select their currency and their country or region on the storefront. Selectors must follow the [UX guidelines](https://shopify.dev/docs/storefronts/themes/markets/country-language-ux).

Learn more about [selling in multiple currencies](https://help.shopify.com/manual/payments/shopify-payments/multi-currency).

**Language selection** - When merchants sell [in multiple languages](https://shopify.dev/docs/storefronts/themes/markets/multiple-currencies-languages#the-language-selector), customers must be able to select their preferred language on the storefront. Selectors must follow the [UX guidelines](https://shopify.dev/docs/storefronts/themes/markets/country-language-ux).

Learn more about [selling in multiple languages](https://help.shopify.com/manual/cross-border/multilingual-online-store).

**Multi-level menus** - Add [nested menus](https://shopify.dev/docs/storefronts/themes/navigation-search/navigation) so that merchants can create multi-level drop down menus.

Learn more about [setting up drop down menus](https://help.shopify.com/manual/online-store/menus-and-links/drop-down-menus).

**Newsletter forms** - Add a [newsletter signup](https://shopify.dev/docs/storefronts/themes/customer-engagement/email-consent#newsletter-sign-up-form) so that merchants can collect customer email addresses to use in email marketing campaigns.

Learn more about [newsletter signups](https://help.shopify.com/manual/online-store/themes/customizing-themes/add-newsletter).

**Pickup availability** - [Add pickup availability to product pages](https://shopify.dev/docs/storefronts/themes/delivery-fulfillment/pickup-availability) so that merchants can display whether a product is available for local pickup without having to add the product to cart. Pickup availability must be supported on the Product page.

Learn more about [pickup availability](https://help.shopify.com/manual/shipping/setting-up-and-managing-your-shipping/local-methods/local-pickup#show-pickup-availability-to-your-customers).

**Related product recommendations** - Add a section to your product pages that displays an automatically generated list of [related product recommendations](https://shopify.dev/docs/storefronts/themes/product-merchandising/recommendations/related-products). Displaying related products to customers makes it easier for them to discover new products, and can help to increase online store sales.

Learn more about [related product recommendations](https://help.shopify.com/manual/online-store/themes/customizing-themes/add-product-recommendations).

**Complementary product recommendations** - Add [complementary products](https://shopify.dev/docs/storefronts/themes/product-merchandising/recommendations/complementary-products) to product pages so that merchants can display other products that pair well with a product.

Learn more about [complementary product recommendations](https://help.shopify.com/manual/online-store/themes/customizing-themes/add-complementary-products).

**Rich product media** - [Add rich product media](https://shopify.dev/docs/storefronts/themes/product-merchandising/media) such as 3D models, embedded videos, and Vimeo or YouTube videos. Include rich product media in the product template, featured product section, and product forms such as quick view features.**Search box or a link to search** - The search box or a link to search must include the following:

* A [search template](https://shopify.dev/docs/storefronts/themes/architecture/templates/search)

* [Predictive search](https://shopify.dev/docs/storefronts/themes/navigation-search/search/predictive-search) functionality

**Selling plans** - Merchants are able to create selling plans to offer subscriptions. Selected selling plans need to be [shown to customers in the cart](https://shopify.dev/docs/storefronts/themes/pricing-payments/subscriptions/add-subscriptions-to-your-theme#implementing-subscription-displays).

Selling plans must be supported on the Cart page.

Learn more about [subscriptions](https://help.shopify.com/manual/products/subscriptions).

**Shop Pay Installments** - Add a [Shop Pay Installments banner](https://shopify.dev/docs/storefronts/themes/pricing-payments/installments) on `product.liquid` to let customers know that they have the option to pay for their order using installments. Shop Pay Installments must be supported on the Product page.

Learn more about [Shop Pay Installments](https://help.shopify.com/manual/payments/shop-pay-installments).

**Unit pricing** - Merchants in some areas are required to [show unit prices](https://shopify.dev/docs/storefronts/themes/pricing-payments/unit-pricing).

Unit pricing must be supported on the following pages:

* Collection page

* Product page

* Cart page

Learn more about how merchants can add unit prices to products in [the European Union (EU) and in Switzerland](https://help.shopify.com/manual/products/details/product-pricing/unit-pricing).

**Variant images** - [Enable themes to use variant images](https://shopify.dev/docs/storefronts/themes/product-merchandising/variants) so that merchants can associate an image with a product variant.

Learn more about [adding images to product variants](https://help.shopify.com/manual/products/product-media/add-images-variants).

**Follow on Shop** - Add a **Follow on Shop button** using the [login\_button](https://shopify.dev/docs/api/liquid/filters/login_button) Liquid filter to enable a customer to follow a store in the Shop app.

The branded **Follow on Shop** button colors must not be modified.

Learn more about [Follow on Shop](https://help.shopify.com/manual/online-store/themes/customizing-themes/follow-on-shop).

**Account component** - Add the [`<shopify-account>`](https://shopify.dev/docs/storefronts/themes/customer-engagement/account-component) component to your theme header to provide easy access to customer accounts, encourage customer sign-ins to accelerate checkout and unlock storefront personalization. The component must be visible in both the desktop and mobile header.

Learn more about the [account component](https://shopify.dev/docs/storefronts/themes/customer-engagement/account-component).

***

## 5.​Templates, sections, and blocks

Merchants can use sections and blocks to arrange page templates, which provides more flexibility in their store's content, and allows them to control the look and feel of their online store without needing to edit code.

### Template support requirements

Themes must support the following templates and their formats:

`theme.liquid` (layout file)`404.json``article.json``blog.json``cart.json``collection.json``index.json``list-collections.json``page.json``page.contact.json``password.json``product.json``search.json``gift_card.liquid``settings_data.json` (config file)`settings_schema.json` (config file)

### Section support requirements

All templates must support sections (JSON templates), with the exception of Customer Account pages, Gift Card pages, and Checkout, which don't need to support sections.Themes must include a **Custom Liquid** section. The section needs to include a setting of type [`liquid`](https://shopify.dev/docs/storefronts/themes/architecture/settings/input-settings#liquid), and should be available on all templates that support sections. The **Custom Liquid** section can act as an insertion point for certain types of apps.Header and footer sections must be rendered within [section groups](https://shopify.dev/docs/storefronts/themes/architecture/section-groups). Section groups allow merchants to dynamically add, remove, and reorder sections in the header and footer areas of the layout.

### Block and app block support requirements

Themes must support blocks for all or most elements on the main section of the product page. For example, elements such as product price, product vendor, and product description should each be individual blocks within the main product section. Refer to [Dawn's main product section](https://github.com/Shopify/dawn/blob/main/sections/main-product.liquid) for an example of how these blocks should be implemented.Themes must support [app blocks](https://shopify.dev/docs/storefronts/themes/architecture/blocks/app-blocks) (blocks of type `@app`) in the main product section and featured product section.Introduce **Custom Liquid** blocks into certain sections. Add a **Custom Liquid** block anywhere you'd consider adding an [app block](https://shopify.dev/docs/storefronts/themes/best-practices/templates-sections-blocks#considerations-for-app-blocks), because the **Custom Liquid** block can act as an insertion point for certain types of apps. This block should include a setting of type [`liquid`](https://shopify.dev/docs/storefronts/themes/architecture/settings/input-settings#liquid).

Learn more about [best practices for sections and blocks](https://shopify.dev/docs/storefronts/themes/best-practices/templates-sections-blocks).

**Note:**

Do not include the `config/markets.json` file with your theme when submitting.

***

## 6.​Lighthouse performance and accessibility

Performance and accessibility are important factors for merchants when they choose a theme for their online store. Optimizing your theme for performance and accessibility is key to the success of the merchants that you support, and the experience of their customers.

### Lighthouse performance and accessibility requirements

Themes must have a minimum average Lighthouse performance score of **60** across the theme's product, collection, and home page, for both desktop and mobile. Tests are run using a [benchmark dataset](https://shopify.dev/docs/storefronts/themes/best-practices/performance/testing-for-performance).Themes must have a minimum average Lighthouse accessibility score of **90** across the theme's product, collection, and home page, for both desktop and mobile. Tests are run using a [benchmark dataset](https://shopify.dev/docs/storefronts/themes/best-practices/performance/testing-for-performance).

When verifying performance and accessibility scores, sections must contain actual images and content. The sections can't be empty.

### Testing the performance of your theme

You can quickly test the [performance](https://shopify.dev/docs/storefronts/themes/best-practices/performance) of your theme before you submit it to the Shopify Theme Store by running performance tests against a benchmark shop. If you want to test your theme before you submit it, then refer to these [performance best practices](https://shopify.dev/docs/storefronts/themes/best-practices/performance/testing-for-performance).

### Testing the accessibility of your theme

You can quickly test the [accessibility](https://shopify.dev/docs/storefronts/themes/best-practices/accessibility) of your theme before you submit it to the Shopify Theme Store by running accessibility tests against a benchmark shop. If you want to test your theme before you submit it, then refer to these [accessibility best practices](https://shopify.dev/docs/storefronts/themes/best-practices/accessibility#accessibility-testing).

***

## 7.​Pages

Including well-designed page types in your theme enables merchants to build all of the elements they need to run their online store.

### Layout page requirements

If payment method logos are output, then use the `enabled_payment_types` property of the [`shop`](https://shopify.dev/docs/api/liquid/objects/shop) [object](https://shopify.dev/docs/api/liquid/objects/shop), and the [`payment_type_img_url`](https://shopify.dev/docs/api/liquid/filters/payment_type_img_url) or [`payment_type_svg_tag`](https://shopify.dev/docs/api/liquid/filters/payment_type_svg_tag) filter, to output payment icons. The icons must be in full color.The `<html>` element must specify a `lang` attribute. The `lang` attribute value can be populated with the `locale` property of the [`request`](https://shopify.dev/docs/api/liquid/objects/request#request-locale) [object](https://shopify.dev/docs/api/liquid/objects/request#request-locale).

```liquid
<html ... lang="{{ request.locale.iso_code }}">
```

You must use the [`routes`](https://shopify.dev/docs/api/liquid/objects/routes) [object](https://shopify.dev/docs/api/liquid/objects/routes) for generating dynamic URLs to your storefront. Instead of `href=/` to link to the homepage, you can now use `href="{{ routes.root_url }}"`. This ensures that your theme supports any changes that Shopify makes to the URL format, such as allowing a page to be available in multiple languages.Don't modify or parse the `content_for_header` object. If `content_for_header` changes, then your Liquid's behavior changes.

### Product page requirements

The product page must contain the following product information:

* `product.title` (not truncated)

* `variant.price`

* `variant.unit_price`

* variant's compare-at price

* `product.description`

* option names and option values

All product images must be displayed and viewable. Different image ratios shouldn't break the layout.Variant images must be shown when the associated variant is selected.The product page must use `cart.taxes_included` to display an indication that taxes are included in the price when a store is using tax-inclusive prices.The product page must contain the following buying functions:

* Variants that are split up into separate options for users to select.

* The ability to select a quantity.

* An **Add to cart** button (often disabled or replaced when an unavailable variant combination, or sold-out variant, is selected).

* A callback function to update the price, compare-at-price, and sold-out messages for the currently selected variant.

* The [first available variant](https://shopify.dev/docs/api/liquid/objects/product#product-selected_or_first_available_variant) loads on a page.

The product page must support the following features:

* Product recommendations

* Rich product media

* Accelerated checkout buttons (must be enabled by default)

* Pickup availability

* Shop Pay Installments

Gift card products must have the option to send the card to a [recipient](https://shopify.dev/docs/api/liquid/objects/gift_card#gift_card-recipient).

The following attributes of the [`form`](https://shopify.dev/docs/api/liquid/objects/form) [object](https://shopify.dev/docs/api/liquid/objects/form) must be used:

* `form.email`

* `form.name`

* `form.message`

The following attribute of the [`gift_card`](https://shopify.dev/docs/api/liquid/objects/gift_card) [object](https://shopify.dev/docs/api/liquid/objects/gift_card) must be used:

* `send_on`

For product options, swatches must be supported to visually display either a hex or an image of the given product option. Use the following attributes of the `swatch` [object](https://shopify.dev/docs/api/liquid/objects/swatch) output:

* `swatch.image`

* `swatch.color`

### Collection page requirements

Attributes of the [`collection`](https://shopify.dev/docs/api/liquid/objects/collection) [object](https://shopify.dev/docs/api/liquid/objects/collection) that must be outputted:

* `collection.title` (not truncated)

* `collection.description`

* `collection.image`

Products must be listed in a grid or list, with the following attributes of the [`product`](https://shopify.dev/docs/api/liquid/objects/product) [object](https://shopify.dev/docs/api/liquid/objects/product) output:

* `product.title` (not truncated and links to product.url)

* `product.price`

* `product.images`

* `variant.unit_price`

* At least one piece of media for a product

Product grid must not break because of product images of varying aspect ratios.The **Sale** badge or `product.compare_at_price_max` is shown when appropriate.Must provide the ability to sort the products inside [collections](https://shopify.dev/docs/storefronts/themes/architecture/templates/collection).Must display a message if a collection has no products in it.If a product has variants with different prices, then use `product.price_varies` to show the price variation. For example, show the range between `product.price_min` and `product.price_max`.Must use [pagination or lazy loading](https://shopify.dev/docs/api/liquid/tags/paginate).

### Collection List page requirements

Attributes of the [`collection`](https://shopify.dev/docs/api/liquid/objects/collection) [object](https://shopify.dev/docs/api/liquid/objects/collection) that must be outputted:

* `collection.title` (not truncated)

Must use `collection.featured_image`. If a [collection image](https://shopify.dev/docs/api/liquid/objects/collection#collection-image) doesn't exist, this property loads the featured image of the first product in that collection instead.Must use [pagination or lazy loading](https://shopify.dev/docs/api/liquid/tags/paginate).

### Cart page requirements

Must display details of the [`line_item`](https://shopify.dev/docs/api/liquid/objects/line_item) [object](https://shopify.dev/docs/api/liquid/objects/line_item), including:

* `title`

* `unit_price`

* `image`

* `final_price`

* `quantity`

* `options_with_values`

The [`cart.total_price`](https://shopify.dev/docs/api/liquid/objects/cart#cart-total_price) must be visible.The cart page must use `cart.taxes_included` to display an indication that taxes are included in the price when a store is using tax-inclusive prices.Must include a checkout button that submits the cart form.Must refresh all line items when the quantity is updated to ensure the total updates correctly.Must provide the ability to change the quantity of each line item.Must display a message when the cart is empty.The cart page must support the following features:

* Cart notes

* Selling plans

* Automatic discount codes

* Accelerated checkout buttons (must be enabled by default)

### Page requirements

Must include:

* `page.title`

* `page.content`

Must include an alternate template for a contact form.

### Blog page requirements

Attributes of the [`blog`](https://shopify.dev/docs/api/liquid/objects/blog) [object](https://shopify.dev/docs/api/liquid/objects/blog) must output the [blog.title](https://shopify.dev/docs/api/liquid/objects/blog#blog-title).Each [article](https://shopify.dev/docs/api/liquid/objects/article) must display the following information:

* `article.title` (not truncated, links to `article.url`)

* `article.image`

* `article.excerpt_or_content` not `article.content`

Must use [pagination or lazy loading](https://shopify.dev/docs/api/liquid/tags/paginate).

### Article page requirements

An [article](https://shopify.dev/docs/api/liquid/objects/article) must display the following information:

* `article.title` (not truncated)

* `article.comments`

* `article.published_at` (but not `article.created_at`)

Comments must be [paginated](https://shopify.dev/docs/api/liquid/tags/paginate).Comments workflow must function without moderation, and all success or error messages must be properly output.

### Search page requirements

Must return a message if there are no search results.Must have the ability to return different object types (products, blogs, pages). The `object_type` must be used when displaying [search results](https://shopify.dev/docs/api/liquid/objects/search).[Pagination or lazy loading](https://shopify.dev/docs/api/liquid/tags/paginate).

### 404 page requirements

Must have a clear message stating that the page wasn't found.Must have options for how to proceed, such as a search bar or a link to the homepage.

### Gift Card page requirements

Must support [Apple Wallet](https://shopify.dev/docs/storefronts/themes/architecture/templates/gift-card-liquid#apple-wallet-passes).Must show a gift card code.Must show a QR code. The minimum size required is 120px x 120px.Must include the logo or `shop.name`.

### Password page requirements

Must include the following information:

* the logo or `shop.name`

* `shop.password_message`

* a way to enter the [storefront’s password](https://shopify.dev/docs/api/liquid/tags/from#form-storefront_password)

***

## 8.​Consistency and functionality

Building a theme that functions properly and consistently ensures that merchants can rely on the quality of your theme.

All themes must meet the following functional requirements:

All RTE-generated content must be consistent (such as `h1`-`h6`, `blockquotes`, `ul`, `ol`) across all templates. Styling of RTE content is consistent with those of blog articles, product descriptions, and collection descriptions.Scripts included in theme code must be hosted on Shopify's servers, with the exception of approved third-party libraries.Themes must not include any Javascript or code that interferes with, or augments, any native Shopify feature within the theme editor or Shopify admin.Any link in the code that points to one of Shopify's domains can take multiple attributes, but must include a `rel="nofollow"` attribute.You must link assets using protocol-relative URLs. Hard-defining `http` or `https` isn't permitted.The appropriate licenses must be obtained for all third party plugins and images.Themes must not include functionality that's dependent on an app.Themes must not incorporate app-like functionalities that require API access for full functionality. Examples include wishlists, appointment scheduling, cart-level discount codes, or an Instagram feed. Incomplete features resembling those found in apps will not be accepted.Themes must not mislead or deceive merchants or customers with false data or claims. Examples include fake urgency and scarcity tactics like fictitious countdown timers, stock levels, or viewer activity counts.

***

## 9.​Browser compatibility

Ensure that your theme lets merchants access the same information and experience across different browsers.

### Desktop browser requirements

A theme's layout, browsing experience, and purchasing actions must support the following desktop browsers and releases:

Safari - latest two releases for MacChrome - latest three releases for Mac and PCFirefox - latest three releases for Mac and PCEdge - latest two releases for PC

### Mobile browser requirements

A theme's layout must meet the following mobile browser layout requirements:

Themes must be mobile responsive.

A theme's layout, browsing experience, and purchasing actions must support the following mobile browsers and releases:

Mobile Safari - latest two releases for iOSChrome Mobile - latest three releases for Android and iOSSamsung Internet - latest two releases for Android

### Webviews and other application requirements

Themes must support browsing and purchasing actions when rendered in webviews for the following applications:

Instagram - latest release for Android and iOSFacebook - latest release for Android and iOSPinterest - latest release for Android and iOS

***

## 10.​Assets

All themes must meet the following requirements, so their assets are delivered by the Shopify platform in an optimal manner.

Themes must not use Sass, or include `.scss` or `.scss.liquid` files. Instead, use only native CSS, and write or compile your stylesheets into `.css` or `.css.liquid` files.Themes must not include minified `.css` or `.js` files, with the exception of ES6 and third-party libraries. Shopify automatically minifies CSS files, as well as JavaScript files that use ES5 syntax or lower, when they're requested by the storefront.

***

## 11.​Search engine optimization (SEO)

Effective SEO helps you build better relationships with your audience, improve the merchant experience, and drive more people to your theme.

All themes must meet the following SEO requirements:

Themes must contain the [theme SEO metadata](https://shopify.dev/docs/storefronts/themes/seo/metadata) code snippet with the title, meta description, and canonical URL.Themes must include Google's rich product snippets. To test your structured data, use [Google's Structured Data Testing Tool](https://developers.google.com/structured-data/testing-tool).Themes must not include a `robots.txt.liquid` template.

Learn more about [SEO best practices](https://shopify.dev/docs/storefronts/themes/seo).

***

## 12.​Accessibility

Accessibility for your theme is essential to providing an inclusive experience for both merchants and customers. An accessible theme is designed so that it can be used by everyone, including people with vision impairment.

All themes must meet the following accessibility requirements:

All parts of a page must be keyboard accessible, including dropdown navigation.When navigating with the keyboard, focusable elements must feature a visible focus state.All images require the `alt` attribute. Themes must use [`image.alt`](https://shopify.dev/docs/api/liquid/objects/image#image-alt) or [`image_url | image_tag: alt: string`](https://shopify.dev/docs/api/liquid/filters/image_tag#image_tag-alt) for product images.Form inputs must have a unique ID, and labels with `for` attributes that match the input ID.Themes must be built with valid HTML.Text color contrast ratio must be 4.5:1 for main body content. For text larger than 18pt, and non-text elements such as borders and icons, the color contrast ratio must be 3:1.Keyboard focus order must match the DOM order. Focus is expected to move top-bottom, left-right.The size of the touch target for pointer inputs must be at least 24 by 24 CSS pixels. The minimum size doesn't apply to inline body text, or elements that meet [other exception criteria](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html).Headings `h1`-`h6` must be visually different from each other.

Learn more about [accessibility best practices](https://shopify.dev/docs/storefronts/themes/best-practices/accessibility).

***

## 13.​Social media

Social media links help merchant grow their followers.

All themes must meet the following requirements for social media:

Must have a set of social media icons to choose from.Must contain [Open Graph](https://ogp.me/) and [Twitter card tags](https://developer.twitter.com/en/docs/twitter-for-websites/cards/overview/markup).Social media placeholder text must be left empty.

***

## 14.​Settings

Settings for sections, blocks, and presets should be clearly named and structured to align with merchant expectations. Avoid unnecessarily deep nesting of blocks or complicated configuration structures that make it hard to find or understand primary controls.

### Basic requirements

All theme settings must adhere to the [text style](#text-style-requirements) and [terminology](#terminology-requirements) requirements.The setting labels and informational text for the theme must be grammatically correct and free of spelling errors.Default setting values for section and block content should indicate how to use the setting. Don't use Lorem Ipsum text or demo store content as a placeholder.Must have a favicon setting.Logo upload must work with images of different aspect ratios (for example, landscape or portrait).All [settings](https://shopify.dev/docs/storefronts/themes/architecture/config/settings-schema-json) must have a `label`.All settings of type `link_list` in the Header or Footer must have a `default` value of `main-menu` or `footer`, depending on the location of the setting.When you supply a default value for resource-based settings such as product, the referenced resource must exist.For [`metaobject`](https://shopify.dev/docs/storefronts/themes/architecture/settings/input-settings#metaobject) and [`metaobject_list`](https://shopify.dev/docs/storefronts/themes/architecture/settings/input-settings#metaobject_list) settings, only standard definitions can be used as `metaobject_type`. Custom or app-owned definitions cannot be used.Must have a [`theme_info`](https://shopify.dev/docs/storefronts/themes/architecture/config/settings-schema-json) section.

### Theme editor event requirements

Changes made in the theme editor must be reflected in the editor preview. Refer to [`request.design_mode`](https://shopify.dev/docs/api/liquid/objects/request#request-design_mode) for troubleshooting.

### Text style requirements

Write section, preset, and category names in sentence case. Only capitalize the first word and proper nouns (like 'Facebook').Use descriptive setting names for multi-option settings or sections of different variations. Avoid using numbered options or section titles, with the exception of colors and color palettes.

| Use this                                    | Don't use this |
| ------------------------------------------- | -------------- |
| Logo position on large screens- Middle left | <br />         |

* Top left

* Top center | Logo position on large screens- Position 1

* Position 2

* Position 3 |
  \| Theme sections- Collage

* Image banner

* Image with text | Theme sections- Image 1

* Image 2

* Image 3 |

Use language that's intuitive and easy to understand for all merchants. For example:

* Use "Horizontal position" or "Vertical position" instead of "X position" or "Y position".

* Use "Button label" instead of "CTA label".

Use American English.

| Use this             | Don't use this  |
| -------------------- | --------------- |
| **canceled**         | cancelled       |
| **catalog**          | catalogue       |
| **center, centered** | centre, centred |
| **color**            | colour          |
| **customize**        | customise       |
| **dialog**           | dialogue        |
| **gray**             | grey            |
| **organize**         | organise        |

Don't use ampersands ( **&** ).Use declarative statements instead of questions.

| Use this              | Don't use this     |
| --------------------- | ------------------ |
| **Use a custom logo** | Use a custom logo? |

The subject of each section (like 'slideshow') is stated only once in the heading. Avoid subject repetition, such as 'slideshow', 'slideshow color', and 'slideshow image'.Use active voice.All buttons and actions must start with a verb.All technical specifications follow these formats:

| Technical specification | Format                                                      | Example                       |
| ----------------------- | ----------------------------------------------------------- | ----------------------------- |
| Image size              | \[numeral] x \[numeral]px (required/recommended)            | 64 x 64px required            |
| Image size              | \[numeral]:\[numeral] aspect ratio (required/recommended)   | 3:2 aspect ratio recommended  |
| Image size with format  | \[numeral] x \[numeral]px \[.format] (required/recommended) | 1200 x 300px .jpg recommended |
| Word / character count  | \[numeral] words (max)                                      | 32 words max                  |
| Text format             | Use basic HTML to format text                               | <br />                        |

### Terminology requirements

Use the following Shopify terminology throughout your theme:

| Use this                                                                                                          | Don’t use this              |
| ----------------------------------------------------------------------------------------------------------------- | --------------------------- |
| **home page**                                                                                                     | homepage                    |
| **top bar**                                                                                                       | meta-nav, search bar        |
| **bottom bar**                                                                                                    | below footer, legal         |
| **slideshow**                                                                                                     | slider                      |
| **checkout** (when naming settings)                                                                               | check out                   |
| **heading**                                                                                                       | title                       |
| **subheading**                                                                                                    | sub-heading                 |
| **body text**                                                                                                     | main text                   |
| **signup**                                                                                                        | sign-up, sign up            |
| **favicon**                                                                                                       | shortcut icon, website icon |
| **sidebar**                                                                                                       | side bar                    |
| **button label**                                                                                                  | button name                 |
| **social media** (when naming sections or settings)                                                               | social, social sharing      |
| **social media icons**                                                                                            | social media buttons        |
| **navigation** (to refer to all navigational elements)                                                            | menus, menu                 |
| **main menu** (to refer to primary navigational element)                                                          | navigation, menu            |
| **secondary menu** (to refer to secondary navigational element)                                                   | navigation, menu            |
| **footer menu** (to refer to a menu located in the footer)                                                        | navigation, menu            |
| **cart type** (with "drawer", "page", and/or "modal" options)                                                     | Ajax, Ajaxify, Ajax cart    |
| **.png**                                                                                                          | PNG, png, .PNG              |
| **use** (for actionable options that include a next step, such as uploading a file)                               | show, enable                |
| **show** (for options that allow the merchant to show or hide a basic element)                                    | use, enable                 |
| **enable** (for options related to apps or plugins, or something that will significantly modify the theme layout) | use, show                   |

### Section name guidelines

Each section in a theme needs a name. Section names appear in the section picker and in the sidebar listing the sections in a template.

Section names should relate to the section's function, for example `Header`, `Product list`, `Slideshow`, or `Image gallery`.

Refer to [Shopify's theme terminology list](https://shopify.dev/docs/storefronts/themes/store/requirements#terminology-requirements) to make sure that you name sections using the right Shopify terms.

#### Suggested section names

* Header

* Featured products

* Featured collections

* Slideshow

* Image gallery

* Logo list

* Newsletter

* Map

* Blog posts

* Testimonials

* Footer

### Section preset guidelines

Section presets are predefined configurations of sections that merchants start with when adding content.

Preset names should relate to the type of content in the preset, for example `Image and text`, `Map`, `Columns`, or `Blog articles`.

Refer to [Shopify's theme terminology list](https://shopify.dev/docs/storefronts/themes/store/requirements#terminology-requirements) to make sure that you name presets using the right Shopify terms.

#### Content placeholders

If your preset features images, videos, or icons, then you should display [placeholder content](https://www.shopify.com/ca/partners/blog/placeholder-images) so that the merchant can get a better idea of how the content looks before they add their own media.

In your presets, use the following content placeholders:

| Type of content                                                            | Placeholder                                                             |
| -------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| Images that aren't products or collections Adjacent images without margins | Image icon                                                              |
| Lists of logos                                                             | Logo icon                                                               |
| Slideshows Images with overlaid text Full-width images                     | Lifestyle image                                                         |
| Videos                                                                     | [Default YouTube video ID](https://www.youtube.com/watch?v=_9VUPq3SxOc) |

***

## 15.​Font picker

Font picker fields can be used to capture a font selection for various theme elements, such as the base heading font.

Font pickers must have the following settings:

All fonts must use the setting type [font\_picker](https://shopify.dev/docs/themes/architecture/settings/input-settings#font_picker).A default font is loaded. For example, `default: work_sans_n6`.Fonts used in defaults and presets must use a currently [available font](https://shopify.dev/docs/storefronts/themes/architecture/settings/fonts#available-fonts).The CSS file loads bold, italic, and bold-italic variants for each font using the `font_modify` filter.Custom fonts aren't accepted.

Learn more about [setting fonts](https://shopify.dev/docs/storefronts/themes/architecture/settings/fonts).

***

## 16.​Color system

Selecting the right foreground and background colors enhances the effectiveness of your theme.

A minimum of 4 colors are required.All background color settings must include a corresponding foreground color setting.Color settings must use a `type` of `color`.

Learn more about [color system best practices](https://shopify.dev/docs/storefronts/themes/best-practices/design/color-system).

***

## 17.​Responsive images

Responsive images are important to the user experience. With the shift to smaller devices, developers face new challenges to ensure that images load quickly, regardless of screen size.

All themes must meet the following image requirements:

Images must adopt a responsive image strategy. Small images such as icons are an exception.Images must load only as they are needed to minimize the number of images loaded initially per page.

***

## 18.​Naming themes and theme presets

Choose clear and unique names for your theme and presets when submitting to the Theme Store. Good names help merchants quickly identify and understand your theme.

### Theme and preset naming requirements

Theme and preset names must be distinct from Shopify products. You can't use the same name as, or similar to, Shopify products, events, or branded content. For example, don't name your theme Shopify, Unite, or Polaris.Theme and preset names must be distinct from company names. You can’t include the name of your company or Shopify Partner account in your theme name. Your Partner account name is displayed automatically on the theme listing page.Theme and preset names must be distinct from websites, ecommerce platforms, and SEO-related benefits. For example, don't name your theme Performance, Mobile, or Sales.Theme and preset names must be distinct from industries and collections in the Theme Store. For example, don't name your theme Fashion, Electronics, or Jewelry.One theme preset must take the name of the parent theme.Theme and preset names must be 1-2 words.Theme and preset names must be less than 30 characters.Theme and preset names must be unique and distinct from existing themes in the Shopify Theme Store to avoid confusion or conflicts.

### Theme and preset name guidelines

Use the following guidelines to help you choose the right name for your theme and presets:

* Summarize, or allude to, the purpose of the theme preset.

* Give the merchant an idea of what to expect when using the theme preset, the core ideas behind the preset, and the preset's target demographic.

* Use a noun for the name. Nouns are more suitable for creating product names that stick, have identity, and create a lasting impression. A noun can better define the focus of the theme, and offer a better understanding of the shopping experience being offered.

* Use a name that's easy to spell and pronounce. This will help merchants with recall and search.

* Work across different dialects. Since some words and phrases can have different meanings in different regions, you should consult with an idiom dictionary.

* Use a name that's different from theme names on different platforms.

### Increasing clarity and discoverability

For clarity and discoverability, consider the following guidelines when naming your theme and preset:

* Don't use trendy names. Trends fade, and theme names should transcend trends.

* Don't use unusual spellings. Not only are unusual spellings more difficult to remember, but they’re also more susceptible to autocorrect errors, and they limit discoverability by merchants.

* Don't use lengthy names. Even if you’re trying to be descriptive, creating a long name can hurt a merchant’s ability to remember what your theme is called.

* Don't use the same name as a theme on a different platform.

* Don't use the same name as an existing theme and preset name.

### Adding presets to your theme zip submission

If you have more than one preset, you need to include a unique set of [templates](https://shopify.dev/docs/storefronts/themes/store/requirements#5-templates-sections-and-blocks) showcasing each preset. The contents of these templates should be similar to the [demo store](https://shopify.dev/docs/storefronts/themes/store/requirements#20-demo-stores) it is associated with.

Preset templates need to be included in a `/listings` folder in your theme zip. See the following example of a theme with two presets:

## Shopify theme preset file structure

```text
.
├── assets
├── blocks
├── config
├── layout
├── locales
├── listings
    ├── preset-name-one
        └── templates
            └── *.json
        └── sections (optional)
            └── *.json
    └── another-preset-name
        └── templates
            └── *.json
        └── sections (optional)
            └── *.json
├── sections
├── snippets
└── templates
```

**Note:**

If you only have one preset, you do not need to include the `/listings` folder.

You can optionally include preset-specific [section groups](docs/storefronts/themes/architecture/section-groups) under a `/sections` folder under your preset listing folders. To learn more about how theme zips should be structured, refer to the [themes architecture documentation](https://shopify.dev/docs/storefronts/themes/architecture).

For a more detailed example of how to structure presets in your theme zip, refer to this [best practices page](docs/storefronts/themes/store/success/updates#best-practices-on-structuring-your-theme-zip).

### Preset parity with demo store (install state)

* On install, the theme should match the demo store’s look and expectations.

* If multiple presets are offered, then each preset’s install state should mirror its demo.

* Layout and color/typography settings must match the demo.

* Use demo copy where appropriate. Adjust or remove copy that could cause support issues. We recommend that you use industry-specific copy, but this is optional.

* Demo imagery doesn't transfer on install.

***

## 19.​Theme versions and release notes

Theme versions help merchants easily identify which theme they have, so that they can determine which features are available, or if there are more recent versions to update to.

When you submit your theme to the Shopify Theme Store, either for the first time or for an update, the theme needs to have a [version number](https://shopify.dev/docs/storefronts/themes/store/success/updates#versioning) and [release notes](https://shopify.dev/docs/storefronts/themes/store/success/updates#release-notes) that highlight the main features of the version.

***

## 20.​Demo stores

Setting up a demo store is a great way to showcase your theme's features and functionality, and to provide merchants with real-world examples of how they can use your theme. A demo store that's beautifully designed and functions flawlessly lets merchants explore and interact with your theme, and helps them understand if your theme is right for them.

To build your demo store, create a [Client transfer store](https://help.shopify.com/en/partners/manage-clients-stores/client-transfer-stores/create-client-transfer-stores) from your Shopify Partner Dashboard.

**Note:**

Development stores with developer previews enabled can't be transferred.

### Demo store requirements

All theme presets must include at least one demo store.Each demo store must match the primary industry and catalog size that the theme preset is tagged to.Each theme preset install store must match the expectations set by the demo store.Each demo store has the [Bogus Gateway](https://help.shopify.com/manual/checkout-settings/test-orders#place-a-test-order-by-simulating-a-transaction) or Shopify Payments [test mode](https://help.shopify.com/manual/payments/shopify-payments/testing-shopify-payments#test-mode) enabled, and all other checkout options disabled.All demo store pages must use authentic text content. Don't use Lorem Ipsum or onboarding text. Don't include profanities.The [`powered_by_link`](https://shopify.dev/docs/api/liquid/objects/powered_by_link) link can't be altered and must contain only `powered_by_link`.Affiliate linking isn't allowed.Any link in the code that points to one of Shopify's domains must include a `rel="nofollow"` attribute.To avoid potential merchant confusion, demo stores can only showcase elements and functionality that are built into the theme. For example:

* Don't use embedded text or buttons in images, except for the text on physical products, infographics, badges, or instagram images.

* Don't use animated gif images in places where they can be mistaken for theme functionality.

* Don't use apps. In some cases, special consideration applies to free product review apps and [free translation apps](https://apps.shopify.com/categories/store-design-internationalization). If you're showcasing multi-language options using translation apps, then all content must be translated.

You must obtain the appropriate rights for all demo store assets in accordance with the [Shopify Partner Agreement](https://www.shopify.com/ca/partners/terms#:~:text=Each%20Theme%20Developer,any%20third%20party.). Before using any brand names, images, or content, permission must be directly granted by the brand owners.\
\
If you’re looking for a good source of royalty-free images, then try [Shopify Burst](https://burst.shopify.com/).

### Demo store recommendations

When designing your demo store, consider the following recommendations to help you showcase the full potential of your theme. The following recommendations aren't mandatory requirements that need to be met for submission.

* Identify the source of any product images used in the product description.

* Use the latest version of your theme in your demo store.

* Incorporate built-in Shopify features to showcase the power and capabilities of your theme.

* Illustrate the versatility and variability of your theme, by including examples such as a product that's on sale, a sold-out product or variant, a product with multiple variants, and a gift card product.

***

## 21.​Documentation and contact forms

Having clear, detailed, and accessible information about your theme helps merchants feel supported and helps to reduce support issues. Creating organized and effective documentation is important to your overall success as a Theme Partner.

### Documentation and contact form requirements

You must provide theme documentation and a public support contact form.You must have your theme documentation and contact form ready before launching your theme.You must link your documentation and contact form to your theme listing page in the Shopify Theme Store.

### Merchant-facing theme documentation

The copy for all theme documentation must be grammatically correct and free of spelling errors.The theme documentation must be consistent with the copy in the theme settings.

You need to keep your documentation up to date as changes occur within Shopify and you update your theme. As you support merchants using your theme, be sure to identify any gaps in your theme documentation and make updates as necessary.

Your theme documentation should include an FAQ section and any other relevant information that you feel could help address potential support questions that merchants might have.

#### Clear support policy

Consider specifying your support policy in your theme documentation. As a Theme Partner, you must [support bug fixes and answer any merchant questions regarding your theme](https://shopify.dev/docs/storefronts/themes/store/requirements#merchant-support-requirements). You might want to provide additional services to merchants such as customizations, app-integrations, and help with theme updates, but you can't include these services in the cost of your theme.

#### Clarity on custom two-column MDX tutorials

If you offer custom coding tutorials in your documentation, then specify whether the custom tutorials are supported. Also, include a warning to merchants in your tutorials that they should duplicate their theme before editing their code, and include a suggestion that merchants hire a [Shopify Partner](https://www.shopify.com/partners/directory) for help.

### Contact forms

Your contact form lets merchants contact you. You should include your contact form in your theme documentation. If you use a modal for your contact form, then make sure that it's mobile friendly and linkable from the Theme Store. Try to avoid fields that ask merchants about budget, phone numbers, project type, or other unnecessary questions. You can have a form outlining your agency work on a separate page, but the contact form that you link to from the Theme Store should comply with the following guidelines.

| Field                        | Guideline                                                                                                                                                                                       |
| ---------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| (First and Last) Name Field  | <br />                                                                                                                                                                                          |
| Email Address Field          | <br />                                                                                                                                                                                          |
| Store URL Field              | Include an example URL for clarity, such as <http://www.storename.myshopify.com>.                                                                                                               |
| Description of Problem Field | This should be a text-area field.                                                                                                                                                               |
| File Upload Function         | Allow merchants to highlight their issues with images.                                                                                                                                          |
| Auto-responder Function      | The auto-responder is triggered when the contact form is submitted to reduce the amount of merchants contacting Shopify and Theme Partners asking if their support requests have been received. |
| Theme Name                   | Provide the theme name if you offer multiple themes.                                                                                                                                            |
| Subject                      | If you include this field, then it should auto populate the email subject line.                                                                                                                 |

***

## 22.​Supporting your theme

As a Theme Partner, you're responsible for supporting merchants who use your theme. Being merchant-focused, providing quality support, and having a collaborative attitude with Shopify is essential for the success of your theme.

Merchant support requests are submitted through your [contact form](#contact-forms), which you should link to from the Shopify Theme Store and your theme documentation.

### Merchant support requirements

You must assist merchants with their theme-related questions.You must reply to support requests from merchants within two business days.If there is a technical issue with your theme, such as a broken layout, a dead link, or a logical error, then you're responsible for fixing the issue in a timely manner.You must fix critical bugs immediately or your theme may be temporarily removed from the Theme Store.

#### Tips for improving the merchant installation experience

* Make sure your `.json` files don't include resources specific to your demo store admin (for example, custom metafields or URLs starting with `shopify://`).

* For `link_list` settings in the Header or Footer, always set a default value of `main-menu` or `footer`, depending on the location of the setting.

* When providing default values for resource-based settings (such as products), make sure the referenced resources exist in all stores.

* For `metaobject` and `metaobject_list` settings, only standard definitions can be used as the `metaobject_type`. Custom or app-owned definitions aren't supported.

### Estimating the support workload

Being a Theme Partner is a full-time job, and supporting merchants who use your theme is a large part of that. All of our current Theme Partners have dedicated support teams working for them. If you become a Theme Partner, then you’ll need to consider how to balance Theme Partner work with any other jobs that you're currently doing. New Theme Partners typically underestimate the amount of time that they'll need to allocate to support.

To understand how much effort is required to support a theme, Shopify merchants currently generate thousands of support tickets each month for the paid themes in the Shopify Theme Store, and support requests continue to grow as more merchants join the platform.

***

